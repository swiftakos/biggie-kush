create table if not exists orders (
  id serial primary key,
  nickname text not null,
  phone text not null,
  items jsonb not null,
  note text not null default '',
  total integer not null,
  status text not null default 'nova',
  created_at timestamptz not null default now()
);
