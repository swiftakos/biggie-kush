import { Link } from "@tanstack/react-router";

export function Mark({ className = "size-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <rect width="32" height="32" rx="8" fill="currentColor" className="text-primary" />
      <path
        d="M16 6c.4 3.2 1.6 5.2 4.2 6.4C17.6 13.2 16.4 15 16 18c-.4-3-1.6-4.8-4.2-5.6C14.4 11.2 15.6 9.2 16 6Z"
        fill="#06210c"
      />
      <path d="M16 14v12" stroke="#06210c" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link to="/" className="flex items-center gap-2 text-fg">
          <Mark />
          <span className="font-display text-xl tracking-wide">BIGGIE KUSH</span>
        </Link>
        <nav className="flex items-center gap-1 text-sm text-muted sm:gap-4">
          <a href="/#nabidka" className="hidden px-2 py-2 sm:inline">
            Nabídka
          </a>
          <a href="/#o-nas" className="hidden px-2 py-2 sm:inline">
            O nás
          </a>
          <a
            href="/#objednavka"
            className="rounded-md bg-primary px-3 py-2 font-semibold text-primary-ink"
          >
            Objednat
          </a>
        </nav>
      </div>
    </header>
  );
}
