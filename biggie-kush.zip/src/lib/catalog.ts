export type Product = {
  id: string;
  name: string;
  price: number;
  unit: string;
  blurb: string;
};

export const products: Product[] = [
  {
    id: "classic",
    name: "Classic Biggie Kush",
    price: 150,
    unit: "sáček",
    blurb: "Hustý, zemitý profil. Základ nabídky, pěstovaný bez hnojiv.",
  },
  {
    id: "yellow",
    name: "Yellow Weed",
    price: 150,
    unit: "sáček",
    blurb: "Světlejší květ, měkčí chuť, stejná organická šarže.",
  },
  {
    id: "blue",
    name: "Blue Weed",
    price: 150,
    unit: "sáček",
    blurb: "Chladnější aroma, ručně tříděné vrcholky.",
  },
  {
    id: "maroon",
    name: "Maroon Weed",
    price: 150,
    unit: "sáček",
    blurb: "Tmavší květ, plnější tělo. Prémiová šarže za stejnou cenu.",
  },
  {
    id: "joint",
    name: "Pre-rolled Joint",
    price: 130,
    unit: "kus",
    blurb: "Už srolovaný. Stejná organická surovina, nic navíc.",
  },
];

export const FREE_LIGHTER = "Zapalovač zdarma ke každé objednávce";

export function productById(id: string) {
  return products.find((p) => p.id === id);
}
