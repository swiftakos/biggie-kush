import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { productById } from "@/lib/catalog";

export type OrderItem = { id: string; name: string; qty: number; price: number };

export type OrderRow = {
  id: number;
  nickname: string;
  phone: string;
  items: OrderItem[];
  note: string;
  total: number;
  status: string;
  created_at: string;
};

const ADMIN_PIN = "847291";
const STATUSES = ["nova", "potvrzena", "dorucena"] as const;

function assertPin(pin: string) {
  if (pin !== ADMIN_PIN) {
    throw new Error("Špatný admin kód.");
  }
}

export const placeOrder = createServerFn({ method: "POST" })
  .validator((input: { nickname: string; phone: string; note: string; lines: { id: string; qty: number }[] }) => input)
  .handler(async ({ data }) => {
    const nickname = data.nickname.trim().slice(0, 40);
    const phone = data.phone.trim().slice(0, 24);
    const note = (data.note ?? "").trim().slice(0, 280);
    if (nickname.length < 2) throw new Error("Vyplň přezdívku.");
    if (phone.length < 3) throw new Error("Vyplň telefon ve hře.");

    const items: OrderItem[] = [];
    for (const line of data.lines ?? []) {
      const product = productById(line.id);
      const qty = Math.floor(Number(line.qty));
      if (!product || !Number.isFinite(qty) || qty < 1 || qty > 40) continue;
      items.push({ id: product.id, name: product.name, qty, price: product.price });
    }
    if (items.length === 0) throw new Error("Vyber aspoň jeden produkt.");

    const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);
    const sql = await getSql();
    const rows = await sql<{ id: number }>`
      insert into orders (nickname, phone, items, note, total)
      values (${nickname}, ${phone}, ${JSON.stringify(items)}::jsonb, ${note}, ${total})
      returning id
    `;
    return { id: rows[0].id, total };
  });

export const listOrders = createServerFn({ method: "POST" })
  .validator((input: { pin: string }) => input)
  .handler(async ({ data }) => {
    assertPin(data.pin);
    const sql = await getSql();
    const rows = await sql<{
      id: number;
      nickname: string;
      phone: string;
      items: OrderItem[] | string;
      note: string;
      total: number;
      status: string;
      created_at: string;
    }>`
      select id, nickname, phone, items, note, total, status, created_at
      from orders
      order by id desc
      limit 200
    `;
    return rows.map((row) => ({
      ...row,
      items: typeof row.items === "string" ? (JSON.parse(row.items) as OrderItem[]) : row.items,
      created_at: String(row.created_at),
    })) satisfies OrderRow[];
  });

export const setOrderStatus = createServerFn({ method: "POST" })
  .validator((input: { pin: string; id: number; status: string }) => input)
  .handler(async ({ data }) => {
    assertPin(data.pin);
    if (!STATUSES.includes(data.status as (typeof STATUSES)[number])) {
      throw new Error("Neznámý stav.");
    }
    const sql = await getSql();
    await sql`
      update orders set status = ${data.status} where id = ${data.id}
    `;
    return { ok: true };
  });
