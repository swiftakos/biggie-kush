import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Mark } from "@/components/site-header";
import { listOrders, setOrderStatus, type OrderRow } from "@/lib/orders.functions";

export const Route = createFileRoute("/admin")({ component: Admin });

const labels: Record<string, string> = {
  nova: "Nová",
  potvrzena: "Potvrzená",
  dorucena: "Doručená",
};

function Admin() {
  const load = useServerFn(listOrders);
  const update = useServerFn(setOrderStatus);
  const [pin, setPin] = useState("");
  const [unlocked, setUnlocked] = useState("");
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function open(code: string) {
    setBusy(true);
    setError("");
    try {
      const rows = await load({ data: { pin: code } });
      setOrders(rows);
      setUnlocked(code);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nepovedlo se načíst.");
    } finally {
      setBusy(false);
    }
  }

  async function change(id: number, status: string) {
    if (!unlocked) return;
    await update({ data: { pin: unlocked, id, status } });
    setOrders((rows) => rows.map((row) => (row.id === id ? { ...row, status } : row)));
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <div className="flex items-center gap-2">
            <Mark />
            <span className="font-display text-xl tracking-wide">ADMIN</span>
          </div>
          <Link to="/" className="text-sm text-muted">
            Zpět na web
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10">
        {!unlocked ? (
          <form
            className="mx-auto max-w-sm space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              void open(pin);
            }}
          >
            <h1 className="font-display text-4xl tracking-wide">Přístup jen pro tebe</h1>
            <p className="text-sm text-muted">
              Objednávky nejsou veřejné. Bez kódu je nikdo neuvidí.
            </p>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              autoComplete="current-password"
              className="w-full rounded-md border border-line bg-surface px-3 py-3 outline-none focus:border-primary"
              placeholder="Admin kód"
            />
            {error ? <p className="text-sm text-primary">{error}</p> : null}
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-md bg-primary py-3 font-semibold text-primary-ink disabled:opacity-50"
            >
              {busy ? "Ověřuji…" : "Otevřít objednávky"}
            </button>
          </form>
        ) : (
          <div>
            <div className="flex items-end justify-between gap-4">
              <h1 className="font-display text-4xl tracking-wide">Objednávky</h1>
              <button type="button" className="text-sm text-muted" onClick={() => void open(unlocked)}>
                Obnovit
              </button>
            </div>
            {orders.length === 0 ? (
              <p className="mt-8 text-muted">Zatím nic. Až někdo objedná na webu, objeví se to tady.</p>
            ) : (
              <ul className="mt-6 space-y-3">
                {orders.map((order) => (
                  <li key={order.id} className="rounded-xl border border-line bg-surface p-4">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <p className="font-display text-2xl tracking-wide">
                        #{order.id} · {order.nickname}
                      </p>
                      <p className="text-primary">${order.total}</p>
                    </div>
                    <p className="mt-1 text-sm">Telefon: {order.phone}</p>
                    <ul className="mt-2 text-sm text-muted">
                      {order.items.map((item) => (
                        <li key={item.id}>
                          {item.qty}× {item.name}
                        </li>
                      ))}
                      <li>Zapalovač zdarma</li>
                    </ul>
                    {order.note ? <p className="mt-2 text-sm">Poznámka: {order.note}</p> : null}
                    <div className="mt-4 flex flex-wrap gap-2">
                      {Object.entries(labels).map(([key, label]) => (
                        <button
                          key={key}
                          type="button"
                          onClick={() => void change(order.id, key)}
                          className={
                            order.status === key
                              ? "rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-ink"
                              : "rounded-md border border-line px-3 py-2 text-sm text-muted"
                          }
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
