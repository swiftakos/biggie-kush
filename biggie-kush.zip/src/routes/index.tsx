import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { FREE_LIGHTER, products } from "@/lib/catalog";
import { placeOrder } from "@/lib/orders.functions";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const submit = useServerFn(placeOrder);
  const [qty, setQty] = useState<Record<string, number>>({});
  const [nickname, setNickname] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<{ id: number; total: number } | null>(null);

  const lines = useMemo(
    () =>
      products
        .map((p) => ({ id: p.id, qty: qty[p.id] ?? 0, price: p.price, name: p.name }))
        .filter((l) => l.qty > 0),
    [qty],
  );
  const total = lines.reduce((s, l) => s + l.price * l.qty, 0);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const result = await submit({
        data: {
          nickname,
          phone,
          note,
          lines: lines.map((l) => ({ id: l.id, qty: l.qty })),
        },
      });
      setDone(result);
      setQty({});
      setNote("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Objednávku se nepodařilo odeslat.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <SiteHeader />
      <section className="relative isolate min-h-[70vh] overflow-hidden">
        <img
          src="/hero.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-bg/70" />
        <div className="relative mx-auto flex min-h-[70vh] max-w-6xl flex-col justify-end px-4 py-16">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-primary">
            San Andreas · FiveM roleplay
          </p>
          <h1 className="max-w-3xl font-display text-5xl leading-none tracking-wide sm:text-7xl">
            OBJEDNEJ SI DNES
          </h1>
          <p className="mt-4 max-w-xl text-lg text-fg/90">
            Organicky pěstováno. Bez hnojiv. Prémiová kvalita za nejnižší cenu ve městě a doručení zdarma kamkoliv.
          </p>
          <a
            href="#objednavka"
            className="mt-8 inline-flex w-fit items-center rounded-md bg-primary px-5 py-3 font-semibold text-primary-ink"
          >
            Vybrat zboží
          </a>
        </div>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:grid-cols-3">
          {[
            ["Organicky", "Pěstováno bez hnojiv, ručně tříděné šarže."],
            ["Nejlevnější ve městě", "Sáček za 150 $, joint za 130 $."],
            ["Rychlé doručení", "Zdarma kamkoliv v San Andreas. Zapalovač k objednávce."],
          ].map(([title, body]) => (
            <div key={title}>
              <h2 className="font-display text-xl tracking-wide text-primary">{title}</h2>
              <p className="mt-1 text-sm text-muted">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="nabidka" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="font-display text-4xl tracking-wide">Nabídka</h2>
        <p className="mt-2 max-w-2xl text-muted">
          Čtyři organické šarže a předrolovaný joint. {FREE_LIGHTER}.
        </p>
        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <li key={product.id} className="rounded-xl border border-line bg-surface p-5">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-display text-2xl tracking-wide">{product.name}</h3>
                <p className="shrink-0 text-primary">${product.price}</p>
              </div>
              <p className="mt-2 text-sm text-muted">{product.blurb}</p>
              <p className="mt-4 text-xs uppercase tracking-wider text-muted">za {product.unit}</p>
            </li>
          ))}
          <li className="rounded-xl border border-dashed border-line bg-surface-2 p-5">
            <h3 className="font-display text-2xl tracking-wide">Zapalovač</h3>
            <p className="mt-2 text-sm text-muted">Přibalíme ho zdarma ke každé objednávce. Nic nevyplňuj.</p>
            <p className="mt-4 text-primary">Zdarma</p>
          </li>
        </ul>
      </section>

      <section id="o-nas" className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-16 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-4xl tracking-wide">O Biggie Kush</h2>
            <p className="mt-4 text-muted">
              Malá pěstírna v San Andreas. Květ roste organicky, bez hnojiv a bez zbytečných přísad.
              Cenu držíme nízko schválně — prémiová kvalita nemá být jen pro ty, co mají nejvíc.
            </p>
            <p className="mt-3 text-muted">
              Objednávku potvrdíme telefonem ve hře a dovezeme zdarma na místo, které napíšeš do poznámky.
            </p>
          </div>
          <div className="rounded-xl border border-primary/40 bg-bg p-5 text-sm leading-relaxed text-fg">
            <p className="font-semibold uppercase tracking-wider text-primary">Důležité upozornění</p>
            <p className="mt-3">
              Tato stránka slouží výhradně pro roleplay na FiveM serveru. Jde o fiktivní činnost ve světě
              San Andreas (GTA V). Nejedná se o reálný prodej marihuany ani jiných látek. Ceny, zboží i
              telefony existují jen ve hře. Použití mimo hru není určené a není nabízené.
            </p>
          </div>
        </div>
      </section>

      <section id="objednavka" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="font-display text-4xl tracking-wide">Objednávka</h2>
        <p className="mt-2 text-muted">Vyplň přezdívku a herní telefon. Ozveme se, až bude balík nachystaný.</p>

        {done ? (
          <div className="mt-8 max-w-xl rounded-xl border border-primary bg-surface p-6">
            <p className="font-display text-3xl tracking-wide text-primary">Objednávka #{done.id}</p>
            <p className="mt-2">
              Celkem ${done.total}. Zapalovač je v balíku. Brzy tě kontaktujeme na telefon ve hře.
            </p>
            <button
              type="button"
              className="mt-6 rounded-md border border-line px-4 py-3"
              onClick={() => setDone(null)}
            >
              Nová objednávka
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="mt-8 grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div className="space-y-3">
              {products.map((product) => {
                const n = qty[product.id] ?? 0;
                return (
                  <div
                    key={product.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-line bg-surface px-4 py-3"
                  >
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted">
                        ${product.price} / {product.unit}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        className="size-11 rounded-md border border-line text-lg"
                        onClick={() => setQty((q) => ({ ...q, [product.id]: Math.max(0, n - 1) }))}
                        aria-label={`Méně ${product.name}`}
                      >
                        −
                      </button>
                      <span className="w-6 text-center tabular-nums">{n}</span>
                      <button
                        type="button"
                        className="size-11 rounded-md border border-line text-lg"
                        onClick={() => setQty((q) => ({ ...q, [product.id]: Math.min(40, n + 1) }))}
                        aria-label={`Přidat ${product.name}`}
                      >
                        +
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="h-fit space-y-4 rounded-xl border border-line bg-surface p-5">
              <label className="block text-sm">
                Přezdívka ve hře
                <input
                  required
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  className="mt-1 w-full rounded-md border border-line bg-bg px-3 py-3 text-fg outline-none focus:border-primary"
                  maxLength={40}
                />
              </label>
              <label className="block text-sm">
                Telefon ve hře
                <input
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="mt-1 w-full rounded-md border border-line bg-bg px-3 py-3 text-fg outline-none focus:border-primary"
                  maxLength={24}
                  inputMode="tel"
                />
              </label>
              <label className="block text-sm">
                Poznámka (kde doručit)
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={3}
                  maxLength={280}
                  className="mt-1 w-full rounded-md border border-line bg-bg px-3 py-3 text-fg outline-none focus:border-primary"
                />
              </label>
              <div className="flex items-center justify-between border-t border-line pt-4">
                <span className="text-muted">Celkem</span>
                <span className="font-display text-3xl">${total}</span>
              </div>
              <p className="text-xs text-muted">{FREE_LIGHTER}.</p>
              {error ? <p className="text-sm text-primary">{error}</p> : null}
              <button
                type="submit"
                disabled={busy || total === 0}
                className="w-full rounded-md bg-primary px-4 py-3 font-semibold text-primary-ink disabled:opacity-50"
              >
                {busy ? "Odesílám…" : "Odeslat objednávku"}
              </button>
            </div>
          </form>
        )}
      </section>

      <footer className="border-t border-line px-4 py-8 text-center text-xs text-muted">
        <p>Biggie Kush · pouze FiveM roleplay v San Andreas · žádný reálný prodej</p>
        <Link to="/admin" className="mt-3 inline-block text-muted underline">
          Admin objednávek
        </Link>
      </footer>
    </div>
  );
}
